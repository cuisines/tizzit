package org.tizzit.web.controller

class TizzitController {

    def index = { }
}
